# Depot Notes Picker — PWA Package

This folder contains a tiny Progressive Web App (PWA) that runs fully offline after first load.
Files:
- `index.html`
- `manifest.webmanifest`
- `sw.js` (service worker for offline cache)
- `icon-192.png`, `icon-512.png`

## Install via GitHub Pages (works in the UK)
1. Create a free GitHub account (if you don't have one).
2. Create a repo named `depot-notes`.
3. Upload **all five files** to the repo root.
4. Settings → Pages → Build and deployment:  
   - Source: **Deploy from a branch**  
   - Branch: **main** (`/root`) → Save
5. After a minute, your site will be live at:  
   `https://<your-user>.github.io/depot-notes/`
6. Open the URL on iPad/iPhone in Safari → Share → **Add to Home Screen**.

## Install via Netlify Drop (no account needed)
1. Visit https://app.netlify.com/drop on iPad.
2. Tap **Upload** and select **each file** (5 total). If upload asks for one file at a time, upload them one by one.
3. Netlify gives you a live HTTPS URL instantly.
4. Open that URL in Safari → Share → **Add to Home Screen**.

## iCloud/Google Drive note
Opening `index.html` directly from Files/Drive won't install a PWA. You need it served over HTTP(S). Use GitHub Pages or Netlify Drop above.

## Updating
If you change files later, bump the `CACHE_NAME` in `sw.js` (e.g., `depot-notes-v2`) to ensure iOS grabs the new version.
